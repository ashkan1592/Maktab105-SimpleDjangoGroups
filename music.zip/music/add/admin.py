from django.contrib import admin
from .models import Add
# Register your models here.
admin.site.register(Add)